#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#include "funciones.c"
#define CANT_HABILITADOS 50
#define CANT_ESTACIONADOS 20
#define FIAT 1
#define PEUGEOT 2
#define FORD 3
#define OTRO 4



int main()
{
   // arrays de AUTOMOVILES HABILITADOS
   eAutomovil arrayAutomovil[CANT_HABILITADOS];


   int opcion=0;
   int indiceLugarLibre;
   char patenteAux[10];
   int marcaAux;
   char modeloAux[10];
   int idProfesorAux;


   inicializarArray(arrayAutomovil,CANT_HABILITADOS,-1); /**< Se indica con -1 que esa posicion esta vacia */

while (opcion!=6)
{
opcionMenu(opcion);
        switch(opcion)
{
    case 1:
                indiceLugarLibre = buscarPrimerOcurrencia(arrayAutomovil,CANT_HABILITADOS,-1);
                if(indiceLugarLibre == -1)
                {
                    printf("\n\nNO QUEDAN LUGARES LIBRES!!!\n");
                    break;
                }

                printf("\nALTA\n");

                getValidStringAlfa("Ingrese la patente del automovil: ","La PATENTE DEBE SER ALFANUMERICA\n",patenteAux);
                if(buscarPatente(arrayAutomovil,CANT_HABILITADOS,patenteAux) != -1)
                {
                    printf("\n\ERROR, LA PATENTE YA ESTA HABILITADA!!!\n");
                    break;
                }

                marcaAux =  getValidInt("Ingrese Modelo 1- Fiat 2- Peugeot 3- Ford 4- Otro: ","EL NUMERO INGRESADO NO CORRESPONDE A UNA OPCION\n", 1, 4);

                getValidString("Ingrese EL MODELO del automovil: ","INGRESAR SOLO LETRAS\n",modeloAux);

                idProfesorAux =  getValidInt("Ingrese el ID del Profesor ","El ID debe ser numerico\n", 1, 4);

                cargarAutomovil(arrayAutomovil,indiceLugarLibre,patenteAux,marcaAux,modeloAux,idProfesorAux,);

        break;
}
}

    return 0;
}
