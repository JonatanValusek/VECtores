#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"

typedef struct
{
    char patente[10];
    int marca;
    char modelo;
    int idProfesor;
    int estado;
}eAutomovil;



int getInt(char mensaje[])
{
    int auxiliar;
    printf("%s",mensaje);
    scanf("%d",&auxiliar);
    return auxiliar;
}

float getFloat(char mensaje[])
{
    float auxiliar;
    printf("%s",mensaje);
    scanf("%f",&auxiliar);
    return auxiliar;
}

char getChar(char mensaje[])
{
    char auxiliar;
    printf("%s",mensaje);
    fflush(stdin);
    scanf("%c",&auxiliar);
    return auxiliar;
}

int esNumerico(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if(str[i] < '0' || str[i] > '9')
           return 0;
       i++;
   }
   return 1;
}

int esSoloLetras(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z'))
           return 0;
       i++;
   }
   return 1;
}

/**
 * \brief Verifica si el valor recibido contiene solo letras y n�meros
 * \param str Array con la cadena a ser analizada
 * \return 1 si contiene solo espacio o letras y n�meros, y 0 si no lo es
 *
 */
int esAlfaNumerico(char str[])
{
   int i=0;
   while(str[i] != '\0')
   {
       if((str[i] != ' ') && (str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z') && (str[i] < '0' || str[i] > '9'))
           return 0;
       i++;
   }
   return 1;
}

void getString(char mensaje[],char input[])
{
    printf("%s",mensaje);
    fflush(stdin);
    scanf ("%s", input);
}

int getStringAlfa(char mensaje[],char input[])
{
    char aux[256];
    getString(mensaje,aux);
    if(esAlfaNumerico(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

int getStringLetras(char mensaje[],char input[])
{
    char aux[256];
    getString(mensaje,aux);
    if(esSoloLetras(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}

int getStringNumeros(char mensaje[],char input[])
{
    char aux[256];
    getString(mensaje,aux);
    if(esNumerico(aux))
    {
        strcpy(input,aux);
        return 1;
    }
    return 0;
}


int opcionMenu(char menu[])
{
    int opcion;
    int auxOpcion;

    while(opcion != 6)
    {

        auxOpcion = getInt("\n\n\n1 - ALTA AUTOMOVIL \n2 - BAJA AUTOMOVIL \n3 - INGRESO AUTOMOVIL\n4 - EGRESO AUTOMOVIL\n5 - INFORMAR\n6 - SALIR\n\n\n");

     while (auxOpcion < 0 || auxOpcion > 6)
     {
         auxOpcion = getInt("\n\n\n1 - ALTA AUTOMOVIL \n2 - BAJA AUTOMOVIL \n3 - INGRESO AUTOMOVIL\n4 - EGRESO AUTOMOVIL\n5 - INFORMAR\n6 - SALIR\n\n\n");
     }
        auxOpcion = opcion;
        return opcion;
    }
}

void inicializarArray(eAutomovil arrayAutomovil[],int cantidadDeElementos,int valor)
{
    int i;
    for(i=0;i < cantidadDeElementos; i++)
    {
        arrayAutomovil[i].estado = valor;
    }

int buscarPrimerOcurrencia(eAutomovil arrayAutomovil[],int cantidadDeElementos,int valor)
{
    int i;
    for(i=0;i < cantidadDeElementos; i++)
    {
        if(arrayAutomovil[i].estado == valor)
        {
            return i;
        }
    }
    return -1;
}
int buscarPatente(eAutomovil arrayAutomovil[],int cantidadDeElementos,char valor[10])
{
    int i;
    for(i=0;i < cantidadDeElementos; i++)
    {
        if(arrayAutomovil[i].patente == valor&& arrayAutomoviles[i].estado==1)
        {
            return i;
        }
    }
    return -1;
}


/**
 * \brief Solicita un numero entero al usuario y lo valida
 * \param requestMessage Es el mensaje a ser mostrado para solicitar el dato
 * \param requestMessage Es el mensaje a ser mostrado en caso de error
 * \return El n�mero ingresado por el usuario
 *
 */
int getValidInt(char requestMessage[],char errorMessage[], int lowLimit, int hiLimit)
{
    char auxStr[256];
    int auxInt;
    while(1)
    {
        if (!getStringNumeros(requestMessage,auxStr))
        {
            printf ("%s\n",errorMessage);
            continue;

        }
        auxInt = atoi(auxStr);
        if(auxInt < lowLimit || auxInt > hiLimit)
        {
            printf ("El numero del debe ser mayor a %d y menor a %d\n",lowLimit,hiLimit);
            continue;

        }
        return auxInt;

    }


}

/**
 * \brief Limpia el stdin, similar a fflush
 * \param -
 * \return -
 *
 */
void cleanStdin(void)
{
    int c;
    do {
        c = getchar();
    } while (c != '\n' && c != EOF);
}

/**
 * \brief Solicita un string
 * \param requestMessage Es el mensaje a ser mostrado para solicitar el dato
 * \param requestMessage Es el mensaje a ser mostrado en caso de error
 * \param input Array donde se cargar� el texto ingresado
 * \return -
 *
 */
void getValidString(char requestMessage[],char errorMessage[], char input[])
{

    while(1)
    {
        if (!getStringLetras(requestMessage,input))
        {
            printf ("%s\n",errorMessage);
            continue;
        }
        cleanStdin();
        break;
    }

}
/**
 * \brief Carga los datos de un automovil
 * \param arrayAutomoviles Es el array de autos
 * \param freePlaceIndex Indica la posicion a setear
 * \param codeAux Codigo del libro
 * \param titleAux Titulo del libro
 * \param authorIdAux Id del autor
 * \param stockIdAux Cantidad de ejemplaes disponibles
 * \return -
 *
 */
void cargarAutomovil(eAutomovil arrayAutomovil[],int patenteAux, int marca,char modeloAux[], int idProfesorAux,int estado)
{

    arrayAutomovil[indiceLugarLibre].patente = patenteAux;
    arrayAutomovil[indiceLugarLibre].modelo = stockAux;
    strcpy(arrayAutomovil[indiceLugarLibre].modelo,modeloAux);
    arrayAutomovil[indiceLugarLibre].idProfesor = idProfesorAux;
    arrayAutomovil[indiceLugarLibre].estado = 1;
}

